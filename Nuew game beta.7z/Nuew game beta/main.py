import pygame
import sys
import json

pygame.init()

# ─── Lectura de argumentos ──────────────────────
def cargar_desde_args():
    width, height = 800, 400
    fullscreen = False
    idioma = "es"

    if len(sys.argv) >= 2 and "x" in sys.argv[1].lower():
        try:
            w, h = sys.argv[1].lower().split("x")
            width, height = int(w), int(h)
        except:
            pass

    if len(sys.argv) >= 3:
        fullscreen = sys.argv[2].lower() in ["true", "1"]

    if len(sys.argv) >= 4:
        idioma = sys.argv[3].lower()

    return width, height, fullscreen, idioma

WIDTH, HEIGHT, FULLSCREEN, IDIOMA = cargar_desde_args()
flags = pygame.FULLSCREEN if FULLSCREEN else 0
screen = pygame.display.set_mode((WIDTH, HEIGHT), flags)
pygame.display.set_caption("Carrera Saltarina")

# ─── Carga de textos ────────────────────────────
def cargar_locales(idioma):
    with open("locales.json", "r", encoding="utf-8") as f:
        data = json.load(f)
    return data.get(idioma, data["es"])

textos = cargar_locales(IDIOMA)

# ─── Audio ──────────────────────────────────────
pygame.mixer.music.load("sound/music.mp3")
pygame.mixer.music.set_volume(0.4)
pygame.mixer.music.play(-1)
impacto_snd = pygame.mixer.Sound("sound/impact.wav")

# ─── Reloj y fuente ─────────────────────────────
clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 36)
start_ticks = pygame.time.get_ticks()

# ─── Carga de sprites ───────────────────────────
def cargar_sprite(ruta):
    return pygame.transform.scale(pygame.image.load(ruta).convert_alpha(), (40, 40))

fondo        = pygame.transform.scale(pygame.image.load("fondo.png"), (WIDTH, HEIGHT))
sprite1      = cargar_sprite("sprites/player1.png")
sprite2      = cargar_sprite("sprites/player2.png")
obstacle_img = cargar_sprite("obstacles/obstaculo.png")
enemy_img    = cargar_sprite("enemigos/ene.png")

# ─── Creación de entidades ──────────────────────
def reset_players():
    return pygame.Rect(50, HEIGHT - 40, 40, 40), pygame.Rect(50, HEIGHT - 90, 40, 40)

def create_obstacle(speed):
    return pygame.Rect(300, HEIGHT - 60, 40, 40), 1, speed

def create_enemy():
    return pygame.Rect(WIDTH - 100, HEIGHT - 60, 40, 40)

def mover_enemigo(enemy, objetivo):
    if enemy.x < objetivo.x: enemy.x += 2
    elif enemy.x > objetivo.x: enemy.x -= 2
    if enemy.y < objetivo.y: enemy.y += 1
    elif enemy.y > objetivo.y: enemy.y -= 1

# ─── Inicialización de juego ────────────────────
player1, player2 = reset_players()
obstacle, direccion, obs_speed = create_obstacle(2)
enemy = create_enemy()
goal  = pygame.Rect(WIDTH - 40, 0, 10, HEIGHT)

jumping1 = jumping2 = False
vel_y1 = vel_y2 = 0
gravity = 1.2
winner = ""
rounds = 1

# ─── Bucle principal ────────────────────────────
run = True
while run:
    clock.tick(60)
    screen.blit(fondo, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    keys = pygame.key.get_pressed()

    # Movimiento jugador 1
    if keys[pygame.K_a]: player1.x -= 4
    if keys[pygame.K_d]: player1.x += 4
    if not jumping1 and keys[pygame.K_w]: jumping1, vel_y1 = True, -15

    # Movimiento jugador 2
    if keys[pygame.K_LEFT]:  player2.x -= 4
    if keys[pygame.K_RIGHT]: player2.x += 4
    if not jumping2 and keys[pygame.K_UP]: jumping2, vel_y2 = True, -15

    # Física de salto
    if jumping1:
        player1.y += vel_y1; vel_y1 += gravity
        if player1.y >= HEIGHT - 40:
            player1.y, jumping1 = HEIGHT - 40, False

    if jumping2:
        player2.y += vel_y2; vel_y2 += gravity
        if player2.y >= HEIGHT - 90:
            player2.y, jumping2 = HEIGHT - 90, False

    # Obstáculo móvil
    obstacle.x += direccion * obs_speed
    if obstacle.x <= 0 or obstacle.x + obstacle.width >= WIDTH:
        direccion *= -1

    # Enemigo persigue
    target = player1 if abs(enemy.x - player1.x) < abs(enemy.x - player2.x) else player2
    mover_enemigo(enemy, target)

    # Dibujado
    screen.blit(sprite1, player1)
    screen.blit(sprite2, player2)
    screen.blit(obstacle_img, obstacle)
    screen.blit(enemy_img, enemy)
    pygame.draw.rect(screen, (0, 255, 0), goal)

    # Colisiones
    if not winner:
        if player1.colliderect(obstacle):
            winner = f"{textos['round']} {rounds}: {textos['blue_hit']}"
        elif player2.colliderect(obstacle):
            winner = f"{textos['round']} {rounds}: {textos['red_hit']}"
        elif enemy.colliderect(player1):
            impacto_snd.play()
            winner = f"{textos['round']} {rounds}: {textos['blue_enemy']}"
        elif enemy.colliderect(player2):
            impacto_snd.play()
            winner = f"{textos['round']} {rounds}: {textos['red_enemy']}"
        elif player1.colliderect(goal):
            winner = f"{textos['round']} {rounds}: {textos['blue_speed']}"
        elif player2.colliderect(goal):
            winner = f"{textos['round']} {rounds}: {textos['red_speed']}"

    # Resultado y reinicio
    if winner:
        screen.blit(font.render(winner, True, (0, 0, 0)), (WIDTH // 2 - 240, HEIGHT // 2 - 20))
        pygame.display.flip()
        pygame.time.delay(2000)
        rounds += 1
        obs_speed += 1
        winner = ""
        player1, player2 = reset_players()
        obstacle, direccion, obs_speed = create_obstacle(obs_speed)
        enemy = create_enemy()
        start_ticks = pygame.time.get_ticks()

    # HUD
    seconds = (pygame.time.get_ticks() - start_ticks) // 1000
    screen.blit(font.render(f"{textos['time']}: {seconds}s", True, (0, 0, 0)), (10, 10))
    screen.blit(font.render(f"{textos['round']}: {rounds}", True, (0, 0, 0)), (10, 40))

    pygame.display.flip()

pygame.quit()