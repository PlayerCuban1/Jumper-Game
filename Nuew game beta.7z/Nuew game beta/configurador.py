# configurador.py

import os
import json

# Cargar texto de menú en base al idioma
def cargar_textos_menu(idioma):
    traducciones = {
        "es": {
            "titulo": "CONFIGURADOR DE JUEGO",
            "idioma_preg": "🌐 Elige idioma / Choose language (es/en): ",
            "ancho": "📏 Ingresa el ANCHO (ej: 800): ",
            "alto": "📐 Ingresa el ALTO (ej: 400): ",
            "modo": "\n🎮 Escoge modo:\n  1. Ventana\n  2. Pantalla Completa",
            "modo_opcion": "📺 Opción (1/2): ",
            "confirmacion": "\n✅ Configuración lista:",
            "resolucion": "   Resolución: {}",
            "pantalla": "   Modo: {}",
            "pantalla_valor": {True: "Pantalla completa", False: "Ventana"},
            "lanzar": "\n▶️ ¿Deseas lanzar el juego ahora? (s/n): ",
            "adios": "👋 Configuración completada.",
            "lanzando": "🚀 Iniciando el juego..."
        },
        "en": {
            "titulo": "GAME CONFIGURATOR",
            "idioma_preg": "🌐 Choose language / Elige idioma (en/es): ",
            "ancho": "📏 Enter WIDTH (e.g., 800): ",
            "alto": "📐 Enter HEIGHT (e.g., 400): ",
            "modo": "\n🎮 Choose display mode:\n  1. Windowed\n  2. Fullscreen",
            "modo_opcion": "📺 Option (1/2): ",
            "confirmacion": "\n✅ Configuration ready:",
            "resolucion": "   Resolution: {}",
            "pantalla": "   Mode: {}",
            "pantalla_valor": {True: "Fullscreen", False: "Windowed"},
            "lanzar": "\n▶️ Launch the game now? (y/n): ",
            "adios": "👋 Configuration complete.",
            "lanzando": "🚀 Launching game..."
        }
    }
    return traducciones.get(idioma, traducciones["es"])


def lanzar_juego(resolucion, pantalla_completa, idioma):
    """Lanza main.py con los parámetros escogidos."""
    fullscreen_flag = "true" if pantalla_completa else "false"
    comando = f'python main.py {resolucion} {fullscreen_flag} {idioma}'
    os.system(comando)


def menu_configuracion():
    # Selección de idioma
    idioma = input("🌐 Elige idioma / Choose language (es/en): ").strip().lower()
    textos = cargar_textos_menu(idioma)

    print("\n╔══════════════════════════════╗")
    print(f"║     {textos['titulo']}     ║")
    print("╚══════════════════════════════╝\n")

    ancho  = input(textos["ancho"])
    alto   = input(textos["alto"])
    resolucion = f"{ancho}x{alto}"

    print(textos["modo"])
    modo = input(textos["modo_opcion"]).strip()
    pantalla_completa = (modo == "2")

    print(textos["confirmacion"])
    print(textos["resolucion"].format(resolucion))
    print(textos["pantalla"].format(textos["pantalla_valor"][pantalla_completa]))

    decision = input(textos["lanzar"]).strip().lower()
    if decision in ("s", "y"):
        print("\n" + textos["lanzando"])
        lanzar_juego(resolucion, pantalla_completa, idioma)
    else:
        print("\n" + textos["adios"])


if __name__ == "__main__":
    menu_configuracion()